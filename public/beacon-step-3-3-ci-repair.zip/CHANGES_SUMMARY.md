# BEACON REMOTE — STEP 3.3 DPAPI TAMPER TEST FIX

Target Repository: `cartechautoservice447-collab/BEACON-REMOTE`
Target Branch: `main`
Commit Message: `Fix DPAPI ciphertext tamper offset in DpapiCredentialStoreTests`

## Root Cause Fixed
In `DpapiCredentialStoreTests.RejectsCorruptedTruncatedOrInvalidMagicFiles`, line 157 flipped `bitFlipped[35]` (`HeaderSize + 5` = DPAPI blob offset `5`).
In Windows `crypt32.dll`, DPAPI blob offsets `4..19` contain the unauthenticated `guidCredentialProvider` header field rather than the encrypted payload (`pbData`) or DPAPI HMAC (`pbSign`).
When line 162 recomputed the outer SHA-256 checksum, `ProtectedData.Unprotect` legitimately succeeded because neither `pbData` nor `pbSign` was modified.

## Fix Applied
- Kept `bitFlipped[35] ^= 0x01` (without recomputing outer SHA-256) to verify the outer corruption checksum catches header corruption before calling DPAPI.
- Added post-checksum DPAPI integrity assertions tampering inside both `pbSign` (`ciphertextEnd - 10`) and `pbData` (`ciphertextEnd - 80`) with recomputed outer SHA-256 checksums, verifying `ProtectedData.Unprotect` rejects both with `CredentialStoreCorruptedException`.

## SHA-256 Checksums
5bc914987d29bca592335a97202891b43ef77229ce2d68bbd50f37a01c1d1e9f  .github/workflows/windows-companion-tests.yml
b19c2a5e52bfabaab5eddf30b690b12856f830602216212bac0607b7222c8fed  companion/windows/src/Beacon.Companion.Windows/Credentials/DpapiCredentialStore.cs
6d3f720aeb23de2eb9ab1e456db97957e4a3f39ba230ced966c785aaf3157fea  companion/windows/src/Beacon.Companion.Core/Pairing/PairingClient.cs
5433bc1e3748e7d3e059fc18e3a9f4eb11c5954d4523204d2596ce567b9fc593  companion/windows/src/Beacon.Companion.Core/Security/ServerOriginValidator.cs
34075e822f1a9a861f79c052b4ecc87732ee8e9d1a13fa6d8a02c000640d2dda  companion/windows/tests/Beacon.Companion.Tests/DpapiCredentialStoreTests.cs
d9d34d4fe072e726e0780d672ca0696a944f6b5246405a863c909b7fef010c20  companion/windows/tests/Beacon.Companion.Tests/PairingClientTests.cs
bba46781e4aba750565909a085af8c9f2d5abe5f24fa06e217ee2cc17e55ff7c  companion/windows/tests/Beacon.Companion.Tests/CaptureAndCredentialContractTests.cs
23a1936c302b2889cd055038f235b7d83aee9a196d4c0cb8d0a75e64c9dadaa9  src/lib/remote/protocol-contract.test.ts
