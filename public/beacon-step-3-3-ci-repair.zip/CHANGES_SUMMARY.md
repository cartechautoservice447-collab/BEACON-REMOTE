# Beacon Remote — Step 3.3 CI Repair Package

Commit Message:
Fix Windows companion Step 3.3 CI issues

Target Repository:
cartechautoservice447-collab/BEACON-REMOTE (branch: main)

## Repaired Files Included (Original Directory Structure)

1. companion/windows/src/Beacon.Companion.Windows/Credentials/DpapiCredentialStore.cs
   - SHA-256: 733bbfb0aa6729bbc7a1e2640fb10c63ad3367f35e221268c6bd48e9b6887cca
   - Fix: Replaced explicit `if (credential.IsDisposed) throw new ObjectDisposedException(...)` at line 189 with `ObjectDisposedException.ThrowIf(credential.IsDisposed, credential);` to satisfy Roslyn analyzer rule CA1513 under TreatWarningsAsErrors=true.

2. companion/windows/src/Beacon.Companion.Core/Pairing/PairingClient.cs
   - SHA-256: 31716b56342945e911de1de121ab8cee83f9d742b6c64b9fcd704500550951ed
   - Fix: Replaced `ArrayBufferWriter<byte>` in `WritePinPairingRequestUtf8` and `WriteQrPairingRequestUtf8` with `PinnedZeroingBufferWriter` owning a writable pinned `byte[]`, resolving CS1503 (`ReadOnlySpan<byte>` to `Span<byte>`) on `CryptographicOperations.ZeroMemory` without unsafe casts.

3. companion/windows/tests/Beacon.Companion.Tests/PairingClientTests.cs
   - SHA-256: d9d34d4fe072e726e0780d672ca0696a944f6b5246405a863c909b7fef010c20
   - Fix: Aligned shared pairing fixture assertions with `QrPairingPayloadValidator.IsValidBase64UrlToken` and `DeviceCredential.IsValidTokenFormat`, and added `SerializesLargeEscapedDeviceMetadataAcrossPinnedBufferGrowthForPinAndQrRequests` to test `PinnedZeroingBufferWriter` resize and zeroing.

4. companion/windows/tests/Beacon.Companion.Tests/CaptureAndCredentialContractTests.cs
   - SHA-256: bba46781e4aba750565909a085af8c9f2d5abe5f24fa06e217ee2cc17e55ff7c
   - Fix: Replaced private `cred.TokenBuffer` reference with direct `SensitiveCharBuffer.FromChars(...)` redaction verification.
